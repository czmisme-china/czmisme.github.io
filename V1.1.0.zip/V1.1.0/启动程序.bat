@echo off
start "" "С��ϷV1.1.0.exe"
exit