@echo off
start "" "С��ϷV1.0.1.exe"
exit