@echo off
start "" "С��ϷV1.0.0.exe"
exit